<!DOCTYPE html>
<html lang="en">
<head>
    <title>Lab 5a Q2</title>
</head>
<body>

<?php
$students = [
    [
        "name"    => "Ainul",
        "program" => "BIW",
        "age"     => 21
    ],
    [
        "name"    => "Qeela",
        "program" => "BIT",
        "age"     => 22
    ],
    [
        "name"    => "Natrah",
        "program" => "BIS",
        "age"     => 20
    ],
    [
        "name"    => "Nabil",
        "program" => "BIP",
        "age"     => 23
    ]
];
?>

<h2>Students Information</h2>

<table border="1" cellpadding="8">
    <tr>
        <th>Name</th>
        <th>Program</th>
        <th>Age</th>
    </tr>

    <?php
    foreach ($students as $student) {
        echo "<tr>
                <td>{$student['name']}</td>
                <td>{$student['program']}</td>
                <td>{$student['age']}</td>
              </tr>";
    }
    ?>
</table>

</body>
</html>
